---
name: survey123-schema-sync
description: Generate and update the Survey123 XLSForm and ArcGIS Pro geodatabase domains for the Whatcom Creek salmon monitoring project from its canonical schema.yaml. Use this whenever the user mentions the Survey123 form, XLSForm, Survey123 Connect, form fields, choice lists, domains, validation rules, constraints, relevant/required logic, adding or renaming a field, reach codes, or making the geodatabase match the form, even if they don't mention schema.yaml.
---

# Survey123 + geodatabase from one schema

`docs/schema.yaml` (also in Project knowledge as `02_schema.yaml`) is the only place fields,
domains, and rules are defined. Everything else is generated. This keeps the form, the
geodatabase, the QA script, and the data dictionary from drifting apart.

## Workflow for any field/domain change
1. Edit `schema.yaml` (show the user only the changed lines as a diff).
2. Regenerate the form: `python scripts/build_xlsform.py docs/schema.yaml form/whatcom_salmon.xlsx --version YYYYMMDDHH`
3. In Survey123 Connect: open the survey, replace the XLSForm, **Publish**. Adding fields is safe; renaming/deleting fields or changing types on a published survey with data is NOT — it breaks the hosted layer. Before real data: republish freely. After real data: add new fields only, deprecate old ones in the schema `desc`.
4. In Pro, rerun `scripts/make_gdb_domains.py` against the gdb.
5. Commit schema + xlsx together with a message naming the change.

Never hand-edit choice lists in the xlsx or type domain lists into chat code. Point to the schema.

## Translation rules (what build_xlsform.py does)
| schema | XLSForm |
|---|---|
| `required: true` | `required=yes` + `required_message` |
| `required_if: {obs_type: [a,b]}` | `relevant` = `${obs_type} = 'a' or ...` and `required=yes` (only enforced while relevant) |
| `min/max` | `constraint` `. >= min and . <= max` |
| `max_length` | `constraint` `string-length(.) <= n` + `bind::esri:fieldLength` |
| `not_future` | `constraint` `. <= now()` |
| geopoint | `body::accuracyThreshold` = `gps_accuracy_warn_m` |
| `calc: gps_accuracy` | hidden double: `pulldata("@geopoint", ${location}, "horizontalAccuracy")` |
| `system: true` | `hidden` with `bind::esri:fieldType` |

## Verify in Connect before trusting (Esri syntax drifts by version)
- `observer` uses `calculation ${username}` from a `username` row. If it doesn't populate or isn't editable, switch to a `default` of the observer's name.
- dateTime questions default to the current time in the field app; confirm, otherwise add a default.
- Accuracy threshold warning behavior in the field app.
If something fails, check the current Survey123 XLSForm docs (web search) rather than guessing.

## Phone test (Phase 1)
Submit 5 test records that deliberately hit each rule: count 600, habitat + species, redd without redd_count, future date, 250+ char note. Screenshot the blocking messages for the README. Then delete test records in the AGOL data tab.

## Pro domains
`make_gdb_domains.py` creates `d_<domain>` coded-value domains and `d_<field>_range` range domains, then assigns them to the observations feature class if given. It is untested outside Pro, so run it on a scratch gdb first.
