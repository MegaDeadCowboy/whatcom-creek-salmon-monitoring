---
name: monitoring-qa-release
description: QA/QC checks, open data package export, and the auto-generated data release report (DRR) for the Whatcom Creek salmon monitoring project. Use this whenever the user mentions QA, QC, qa_flag, flags, data validation after collection, pulling the hosted feature layer, ArcGIS API for Python, exporting CSV/GeoJSON/metadata, the data dictionary, the data package, the data release report, DRR, or Quarto, even if they only say "run the pipeline" or "the report."
---

# QA → data package → DRR

All three steps read `docs/schema.yaml`. Don't hard-code field names, domains, ranges, or
flag codes in new code; read them from the schema.

## Files (copy into the repo; don't regenerate from scratch)
- `scripts/qa_pipeline.py` → repo `scripts/qa_pipeline.py`. Tested on synthetic data covering every flag code. The `load_from_agol` function is untested; debug it against the real item.
- `assets/data_release_report.qmd` → repo `report/data_release_report.qmd`

## Run
```
python scripts/qa_pipeline.py --schema docs/schema.yaml --item <ITEM_ID> --out data/release
cd report && quarto render data_release_report.qmd --to html   # add --to pdf if TinyTeX is installed
```
Outputs in `data/release/`: `observations.csv`, `observations.geojson`, `qa_summary.csv`,
`data_dictionary.csv`, `metadata.json`. Also export `reaches.geojson` from Pro into the same folder.

## QA design (interview-ready reasoning)
- Form validation prevents bad entries. The QA script catches what forms can't: duplicates, cross-record consistency (`VISIT_INCONSISTENT`), GPS accuracy, and anything entered in the web form or edited later in AGOL.
- Flags are pipe-delimited codes in `qa_flag`. **Records are flagged, never deleted.** Empty flag = passed. The DRR summarizes on passed records and reports flag counts.
- Zero counts and `no_fish` records are valid data, not errors.
- Duplicates flag *all* members so a human decides which to keep.

## Adding a check
1. Add the code and description under `qa_flags` in the schema.
2. Add the rule in `run_qa` using `flag(mask, CODE)`.
3. Add a synthetic row that triggers it and confirm it's flagged. The summary picks it up automatically.

## Gotchas
- Survey123 stores dates in UTC. `local_date` uses the schema `timezone` for visit grouping and window checks.
- CSV exports from AGOL may format dates in local time, not ISO UTC. Prefer `--item`. If you use `--csv`, check a date against the phone.
- `DATE_FUTURE` compares against the current time. Tests with fake future dates need `run_qa(..., now=...)`.
- Write-back of `qa_flag` to the hosted layer is optional. If doing it, use `FeatureLayer.edit_features(updates=...)` keyed on `objectid`. Keeping QA as a separate output is also defensible (the raw layer stays untouched).

## DRR scope
Sections: abstract, purpose, methods (design, collection, QC), results (counts by reach × species from passed records, map), package contents, limitations, citation. Keep prose placeholders short. The user fills the narrative; the code fills the numbers.
